# myproject
This library has sorting functions and recursive functions.

## building this package locally
`python setup.py sdist`

## installing this package from github
`pip install git+https://github.com/SisoFano/EXPLORE.git`
